package org.glasser.swing;



public interface StatusMessageDisplay {

    public void setStatusMessage(String message);

    public String getStatusMessage();

}

