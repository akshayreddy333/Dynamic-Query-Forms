package org.glasser.swing.table;

public interface ListTableModelListener extends java.util.EventListener {

    public void dataListChanged(ListTableModelEvent ev);

}
