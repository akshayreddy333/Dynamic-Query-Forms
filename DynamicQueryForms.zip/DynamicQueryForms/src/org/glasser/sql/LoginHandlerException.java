package org.glasser.sql;

public class LoginHandlerException extends Exception  {


    public LoginHandlerException() {
        super();
    }

    public LoginHandlerException(String message) {
        super(message);
    }
}

